const express = require ('express')
const app = express();
app.get('/', (req, res) => {
  res.send("coded by tausif")

})
app.listen(3000, () => {
  console.log('server has been started')
  console.log('Tausif On Top Babe')
})