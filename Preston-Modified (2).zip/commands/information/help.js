const {
    MessageEmbed,
    Message,
    MessageActionRow,
    MessageButton,
    MessageSelectMenu,
    Client
} = require("discord.js");
const Settings = require('../../core/settings.js');
const client = require('../../index');
const db = require('../../core/db');

module.exports = {
    name: 'help',
    aliases: ['h'],
    category: 'info',
    run: async (client, message, args) => {
        let prefix = await db.get(`prefix_${message.guild.id}`);
        if (!prefix) prefix = Settings.bot.info.prefix;
        const row = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('helpop')
                    .setPlaceholder(`Choose A Category.`)
                    .addOptions([
                        {
                            label: ' AntiNuke',
                            description: 'Get All AntiNuke Command List',
                            value: 'first',
                        },
                        {
                            label: ' Moderation',
                            description: 'Get All Moderation Command List',
                            value: 'second',
                        },
                        {
                            label: 'Utility',
                            description: 'Get All Utility Command List',
                            value: 'third',
                        },
                        {
                            label: 'Giveaway',
                            description: 'Get All Giveaway Commmand List',
                            value: 'fifth',
                        },
                        {
                            label: 'Fun',
                            description: 'Get All Fun Command List',
                            value: 'fourth',
                        },
                        {
                            label: 'Welcomer',
                            description: 'Get All Welcomer Command List',
                            value: 'sixth',
                        },
                        {
                            label: 'Custom Role',
                            description: 'Get All Custom Role Command List',
                            value: 'seven',
                        }
                    ])
            )
        const embed = new MessageEmbed()
            .setColor("#2f3136")
            .setAuthor(`${client.user.tag} Help Panel`, client.user.displayAvatarURL({ dynamic: true }))

          .setImage(`https://media.discordapp.net/attachments/1229087570097606699/1234857708180475965/IMG_8189.gif?ex=6632425c&is=6630f0dc&hm=2a876dc74df705d4d6aa74174df5a344309d6a66c5080f771a52756105545527&`)
            
            .setDescription(`<a:User:1084404327189332009> **__About Preston__** <a:User:1084404327189332009>\n<a:right_arrow:1229321873721004063> **Prefix For This Server \`${prefix}\`**\n<a:right_arrow:1229321873721004063> **Total Commands - \`114\`**\n\n<:logging:1234860630175907960> **__Important Links__** <:logging:1234860630175907960>\n<a:right_arrow:1229321873721004063> [Invite Preston](https://discord.com/oauth2/authorize?client_id=1228004504486674523&permissions=8&scope=applications.commands%20bot)\n <a:right_arrow:1229321873721004063> [Preston Support](https://discord.gg/6Ufh4tPJ)\n <a:right_arrow:1229321873721004063> [Vote Preston](https://discord.gg/9A5ysAvcY8)\n\n <:logging:1234860630175907960> **__Main Modules__** <:logging:1234860630175907960>\n<:antinuke:1234814766980009984> **Antinuke**\n<:Moderation:1229080338249027596> **Moderation**\n<:Icons_utility:1229085345321058355> **Utility**\n<:icon_giveaway:1234814041717739613> **Giveaway**\n<:fun:1229081417779118160> **Fun**\n<:icons_image:1234813803129077900> **Image**\n<:Customroles:1234814194499452960> **Custom Roles**\n<:welcome:1229083043633954816> **Welcomer**`)
            .setThumbnail(message.guild.iconURL({ dynamic: true }))
        message.channel.send({ embeds: [embed], components: [row] })
    }
}

function embeds(embed, prefix, ping) {
  if (embed === 'help') {
    return new MessageEmbed()
      .setColor('#2f3136')
      .setAuthor(client.user.username, client.user.displayAvatarURL(), "https://discord.gg/9A5ysAvcY8")
      .setDescription(`**<a:right_arrow:1229321873721004063> My Default Prefix Is  ${prefix}**

**<a:right_arrow:1229321873721004063>  A Best Antinuke Security Bot With Many More Advance Features
<a:right_arrow:1229321873721004063>  ${client.user.username} Provides You Best Premium Security Features 
<a:right_arrow:1229321873721004063>  [Invite](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot) | [Support](https://discord.gg/6Ufh4tPJ) | Total Commands 114**

**Choose One Of The Category Below : **

<:logging:1234860630175907960>  **__Main Modules__**
>  **<a:right_arrow:1229321873721004063> Antinuke **
>  **<a:right_arrow:1229321873721004063> Moderation**
>  **<a:right_arrow:1229321873721004063> Whitelist** `);
    
  } else if (embed === 'x') {
    return new MessageEmbed()
      .setColor("#2f3136")
      .setDescription("**MODERATION** `ban`,`kick`,`unban`,`mute`,`unmute`,`lock`,`unlock`,`unhide`,`hide`,`unbanall`,`nuke`")
  } else if (embed === 'toggle') {
    return new MessageEmbed()
    .setColor('#2f3136')
    .setDescription(`**Antinuke Commands Of Preston**

>  To Enable Use :  \`.antinuke enable\`
>  To Disable Use :  \`.antinuke disable\`

Enabling Antinuke Will Feature Your Server : 

• \`Anti Ban\`,\`Anti Kick\`,\`Anti Unban\`,\` Anti Role Create\`,\`Anti Role Update \`,\`Anti Role Delete\`,\` Anti Channel Create\`,\`Anti Channel Delete\`,\`Anti Channel Update\`, \`Anti Emoji Create\` , \`Anti Emoji Delete\` , \`Anti Emoji Update\`,\`Anti Webhook Create \`,\`Anti Webhook Update\`,\`Anti Webhook Delete\`,\`Anti Sticker Create\`,\`Anti Sticker Update\`,\`Anti Sticker Delete\`,\`Anti Everyone/Here \`,\`Anti Server Update \`,\`Anti Prune \`,\`Anti Bot Add \`,\`Anti Vanity Steal \``);

  } 
}
