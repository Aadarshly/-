const prefix = process.env.prefix || '.'
const status = `${prefix}help`;


module.exports = {
  bot: {
    info: {
      prefix: process.env.prefix || '.',
      token: process.env.token,
      invLink: 'https://discord.gg/9A5ysAvcY8',
    },
    options: {
      founders: ['1095264592348852294'],
      privateMode: false,
    },
    presence: {
      name: process.env.statusText || status,
      type: 'streaming',
      url: 'https://twitch.tv/phv08'
    },
    credits: {
      developerId: '1004001053743779870',
      developer: 'Tausif',
    }
  }
}