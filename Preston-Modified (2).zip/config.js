const data = {
    "token": "MTA5NzA1MTY0NjI0MjA4Mjg3Ng.GWS6aV.IP-1x-nWHrENAh6vNC63YtfMQ2aU0K1oHYTlj8" || process.env.token,
    "mongo": "mongodb+srv://rlx:rlx@rlx2.yulr9.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"|| process.env.mongo,
 
}
console.log('got connected from database ..!!')
module.exports = data;